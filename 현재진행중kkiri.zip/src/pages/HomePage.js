import React from "react";
import HomeContainer from "../containers/home/HomeContainer";

function HomePage() {
  return (
    <>
      <div>header</div>
      <HomeContainer />
    </>
  );
}

export default HomePage;
