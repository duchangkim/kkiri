import React from "react";
import styled from "styled-components";

const CalendarFormPopupBlock = styled.div``;

const CalendarFormPopup = () => {
  return <div></div>;
};

export default CalendarFormPopup;
